from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, login_user, LoginManager, login_required, current_user
import pickle
import numpy as np
from flask_wtf import FlaskForm
from wtforms import SelectField, StringField, SubmitField
from wtforms.validators import DataRequired, InputRequired
from flask_cors import CORS


# Establishing Flask Connection
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'secretkey'

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'signin'

# Loading Disease Detection Model
with open("DecisionTree-Model.sav", "rb") as f:
    model_N = pickle.load(f)

# Loading Medicine Recommendation Model
with open("drugTree.pkl", "rb") as f2:
    model_med = pickle.load(f2)

# Mapping Symptoms as indexes in dataset using dictionary
symptom_mapping = {
    'acidity': 0, 'indigestion': 1, 'headache': 2, 'blurred_and_distorted_vision': 3,
    'excessive_hunger': 4, 'muscle_weakness': 5, 'stiff_neck': 6, 'swelling_joints': 7,
    'movement_stiffness': 8, 'depression': 9, 'irritability': 10, 'visual_disturbances': 11,
    'painful_walking': 12, 'abdominal_pain': 13, 'nausea': 14, 'vomiting': 15,
    'blood_in_mucus': 16, 'Fatigue': 17, 'Fever': 18, 'Dehydration': 19,
    'loss_of_appetite': 20, 'cramping': 21, 'blood_in_stool': 22, 'gnawing': 23,
    'upper_abdomain_pain': 24, 'fullness_feeling': 25, 'hiccups': 26, 'abdominal_bloating': 27,
    'heartburn': 28, 'belching': 29, 'burning_ache': 30
}

# Predicting Disease
def serviceValidation(selected_symptoms):
    inputs = [0] * 31
    for symptom in selected_symptoms:
        if symptom:
            inputs[symptom_mapping[symptom]] = 1
    inputs = np.array(inputs).reshape(1, -1)
    predicted_result = model_N.predict(inputs)
    return predicted_result[0]

# Recommending Medicine
def medicineValidation(selectedOptions):
    inputs = np.array(selectedOptions).reshape(1, -1)
    recommend_Med = model_med.predict(inputs)
    return recommend_Med[0]

# ===================== API Routes =====================

# 1. Disease Prediction Route
@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.json
    symptoms = data.get('symptoms')  # Expecting a list of 4 symptoms

    if not symptoms or len(symptoms) != 4:
        return jsonify({"error": "Provide exactly 4 symptoms"}), 400

    try:
        predicted_disease = serviceValidation(symptoms)
        return jsonify({"predicted_disease": predicted_disease}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Expected Body:
# {
#     "symptoms": ["acidity", "headache", "nausea", "Fatigue"]
# }

# 2. Medicine Recommendation Route
@app.route('/api/medicine', methods=['POST'])
def recommend_medicine():
    data = request.json
    try:
        disease = int(data.get('disease'))     # 0 for Diarrhea, 1 for Gastritis, 2 for Arthritis, 3 for Migraine
        age = int(data.get('age'))
        gender = int(data.get('gender'))       # 1 for Male, 0 for Female
        severity = int(data.get('severity'))   # 0 for Few days, 1 for A week, 2 for Few weeks or more

        selectedOptions = [disease, age, gender, severity]
        recommended_medicine = medicineValidation(selectedOptions)
        
        return jsonify({"recommended_medicine": recommended_medicine}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Expected Body:
# {
#     "disease": 0,
#     "age": 25,
#     "gender": 1,
#     "severity": 1
# }

# 3. Doctor Service Route
@app.route('/api/doc_service', methods=['GET'])
@login_required
def doc_service():
    # Example response, customize as needed
    return jsonify({"message": "Available Doctors: Dr. A, Dr. B, Dr. C"}), 200

if __name__ == '__main__':
    app.run(debug=True)
