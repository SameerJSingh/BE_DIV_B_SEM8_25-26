import cloudpickle
import pandas as pd
from flask import Flask, request, jsonify
from flask_cors import CORS

# -------------------------------
# Load trained ML pipeline
# -------------------------------
with open("dosha_pipeline.pkl", "rb") as f:
    pipeline = cloudpickle.load(f)

# -------------------------------
# Flask app setup
# -------------------------------
app = Flask(__name__)

# ✅ Allow all origins temporarily (for debugging)
CORS(app, supports_credentials=True)

# -------------------------------
# Dosha Prediction Route
# -------------------------------
@app.route('/predict_dosha', methods=['POST', 'OPTIONS'])
def predict_dosha():
    if request.method == "OPTIONS":
        # ✅ Handle preflight request
        return jsonify({"message": "CORS preflight OK"}), 200

    try:
        # Get JSON from frontend
        data = request.get_json()
        features = data.get("features", {})

        # Ensure all expected features exist
        expected_features = pipeline.feature_names_in_
        for col in expected_features:
            if col not in features:
                features[col] = "Unknown"

        df = pd.DataFrame([features])
        prediction = pipeline.predict(df)[0]

        response = {
            "Dosha": prediction[0],
            "Yoga": prediction[1],
            "Lifestyle": prediction[2],
            "Exercise": prediction[3],
            "Diet": prediction[4]
        }

        return jsonify(response)

    except Exception as e:
        print("❌ Backend Error:", e)
        return jsonify({"error": str(e)}), 500


# -------------------------------
# Run Flask App
# -------------------------------
if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
