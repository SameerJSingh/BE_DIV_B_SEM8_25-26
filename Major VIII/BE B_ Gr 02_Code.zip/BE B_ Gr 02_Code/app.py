import pandas as pd
import numpy as np
from flask import Flask, request, jsonify
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Embedding, LSTM, Dense
import joblib
from flask_cors import CORS

# ------------------ Disease Prediction Model ------------------

data = pd.read_csv('Disease,Symptoms,Ayurvedic Treatment.csv')

training_sentences = data['Symptoms'].astype(str).tolist()
training_labels = data['Disease'].astype(str).tolist()

tokenizer = Tokenizer(num_words=10000, oov_token="<OOV>")
tokenizer.fit_on_texts(training_sentences)

training_sequences = tokenizer.texts_to_sequences(training_sentences)
max_sequence_len = max([len(x) for x in training_sequences])
padded = pad_sequences(training_sequences, maxlen=max_sequence_len, padding='post')

label_tokenizer = Tokenizer()
label_tokenizer.fit_on_texts(training_labels)
label_word_index = label_tokenizer.word_index

training_label_seq = label_tokenizer.texts_to_sequences(training_labels)
training_label_seq = np.array([item[0] for item in training_label_seq])

# 👉 Try loading model if already saved
try:
    model = load_model("disease_model.h5")
    print("✅ Disease model loaded")
except:
    print("⚠ Training model...")
    model = Sequential([
        Embedding(10000, 16),
        LSTM(32),
        Dense(24, activation='relu'),
        Dense(len(label_word_index) + 1, activation='softmax')
    ])
    model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    model.fit(padded, training_label_seq, epochs=30)
    model.save("disease_model.h5")
    print("✅ Model trained & saved")

# ------------------ Dosha Model ------------------

dosha_model = joblib.load("dosha_pipeline.pkl")
print("✅ Dosha model loaded")

# ------------------ Dosha Label Mapping ------------------

DOSHA_LABELS = {
    0: "Vata",
    1: "Pitta", 
    2: "Kapha",
    3: "Vata+Pitta",
    4: "Pitta+Kapha",
    5: "Vata+Kapha"
}

RECOMMENDATIONS = {
    "Vata": {
        "Yoga": "Balasana, Vrikshasana, Shavasana - calming poses",
        "Lifestyle": "Maintain regular routine, warm environment, adequate rest",
        "Exercise": "Gentle yoga, walking, swimming, avoid overexertion",
        "Diet": "Warm, moist, grounding foods. Sweet, sour, salty tastes"
    },
    "Pitta": {
        "Yoga": "Chandra Namaskar, Sheetali Pranayama - cooling poses",
        "Lifestyle": "Stay cool, avoid midday sun, practice moderation",
        "Exercise": "Swimming, cycling, moderate yoga, avoid overheating",
        "Diet": "Cool, sweet foods. Avoid spicy, sour, salty items"
    },
    "Kapha": {
        "Yoga": "Surya Namaskar, vigorous flows - energizing poses",
        "Lifestyle": "Active lifestyle, early rising, variety in routine",
        "Exercise": "Running, aerobics, vigorous workouts daily",
        "Diet": "Light, warm, spicy foods. Reduce sweet, oily items"
    },
    "Vata+Pitta": {
        "Yoga": "Gentle flow with cooling poses, balance stability and calm",
        "Lifestyle": "Regular routine with cooling activities, manage stress",
        "Exercise": "Moderate yoga, walking, tai chi - avoid extremes",
        "Diet": "Warm but cooling foods. Balance sweet and bitter tastes"
    },
    "Pitta+Kapha": {
        "Yoga": "Dynamic practice with cooling sequences",
        "Lifestyle": "Stay active but cool, avoid excessive heat",
        "Exercise": "Swimming, moderate cardio, balanced yoga",
        "Diet": "Light, cooling foods. Reduce heavy, oily items"
    },
    "Vata+Kapha": {
        "Yoga": "Energizing yet grounding practice",
        "Lifestyle": "Regular activity with warmth, avoid dampness",
        "Exercise": "Brisk walking, light jogging, dynamic yoga",
        "Diet": "Warm, light, spicy foods. Reduce cold, heavy items"
    }
}

# ------------------ Flask App ------------------

app = Flask(__name__)
CORS(app)   # ✅ VERY IMPORTANT (fixes your error)

# ------------------ Disease API ------------------

@app.route('/predict_disease', methods=['POST'])
def predict_disease():
    try:
        req_data = request.get_json()
        Symptoms = req_data.get('Symptoms', '')

        if not Symptoms:
            return jsonify({'error': 'No symptoms provided'}), 400

        input_seq = tokenizer.texts_to_sequences([Symptoms])
        padded_input_seq = pad_sequences(input_seq, maxlen=max_sequence_len, padding='post')

        predictions = model.predict(padded_input_seq)
        predicted_label = np.argmax(predictions)

        Disease = label_tokenizer.index_word.get(predicted_label)

        if Disease is None:
            return jsonify({'error': 'Prediction failed'}), 500

        disease_info = data[data['Disease'] == Disease]

        return jsonify({
            'Disease': Disease,
            'Treatment': disease_info['Treatment'].values[0],
            'Procedure': disease_info['Procedure'].values[0],
            'Precautions': disease_info['Precautions'].values[0]
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ------------------ Dosha API ------------------

@app.route('/predict_dosha', methods=['POST'])
def predict_dosha():
    try:
        req_data = request.get_json()
        features = req_data.get('features', {})

        print("📩 Received Features:", features)  # Debug

        if not features:
            return jsonify({'error': 'No features provided'}), 400

        input_df = pd.DataFrame([features])

        prediction_index = dosha_model.predict(input_df)[0]
        
        dosha_name = DOSHA_LABELS.get(int(prediction_index), "Unknown")
        recs = RECOMMENDATIONS.get(dosha_name, RECOMMENDATIONS["Vata"])

        return jsonify({
            'Dosha': dosha_name,
            'Yoga': recs['Yoga'],
            'Lifestyle': recs['Lifestyle'],
            'Exercise': recs['Exercise'],
            'Diet': recs['Diet']
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ------------------ Run Server ------------------

if __name__ == '__main__':
    app.run(debug=True, port=4000, use_reloader=False)