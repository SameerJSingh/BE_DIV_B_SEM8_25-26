# -*- coding: utf-8 -*-
from flask import Flask, render_template
import pandas as pd
import requests
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import threading
import time
from datetime import datetime

# ----------------- CONFIG -----------------
DB_URL = "https://project-f4333-default-rtdb.firebaseio.com/"
DEVICE_ID = "esp32_node_01"
BASE = f"{DB_URL}/readings/{DEVICE_ID}.json"
UPDATE_INTERVAL = 5  # seconds

# ----------------- FLASK APP -----------------
app = Flask(__name__)
latest_data = pd.DataFrame()

# ----------------- DATA FETCH -----------------
def fetch_all(limit_last=None):
    """Fetch data from Firebase RTDB"""
    params = {"orderBy": '"$key"'}
    if limit_last:
        params["limitToLast"] = str(limit_last)
    try:
        r = requests.get(BASE, params=params, timeout=10)
        r.raise_for_status()
        data = r.json() or {}
    except Exception as e:
        print("Error fetching data:", e)
        return pd.DataFrame(columns=["timestamp","temp_c","heart_rate","spo2","ecg_mv","pulse_digital_bpm"])

    rows = [v for k, v in data.items()]
    if not rows:
        return pd.DataFrame(columns=["timestamp","temp_c","heart_rate","spo2","ecg_mv","pulse_digital_bpm"])

    df = pd.DataFrame(rows)
    df["ts"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True).dt.tz_convert("Asia/Kolkata")
    return df.sort_values("ts").reset_index(drop=True)

def update_data():
    """Update latest_data periodically"""
    global latest_data
    while True:
        latest_data = fetch_all(limit_last=500)
        time.sleep(UPDATE_INTERVAL)

# ----------------- DASHBOARD FIGURES -----------------
def create_dashboard_figures(df):
    if df.empty:
        return {}

    colors = {
        'danger': '#E17055',
        'warning': '#FDCB6E',
        'info': '#74B9FF',
        'secondary': '#A29BFE',
        'primary': '#6C5CE7'
    }

    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('❤️ Heart Rate', '🌡️ Temperature', '🫁 SpO₂', '⚡ ECG Signal'),
        specs=[[{}, {}],[{}, {}]],
        vertical_spacing=0.12, horizontal_spacing=0.1
    )

    fig.add_trace(go.Scatter(x=df['ts'], y=df['heart_rate'], mode='lines+markers',
                             line=dict(color=colors['danger'], width=3)), row=1, col=1)
    fig.add_trace(go.Scatter(x=df['ts'], y=df['temp_c'], mode='lines+markers',
                             line=dict(color=colors['warning'], width=3)), row=1, col=2)
    fig.add_trace(go.Scatter(x=df['ts'], y=df['spo2'], mode='lines+markers',
                             line=dict(color=colors['info'], width=3)), row=2, col=1)

    if 'ecg_mv' in df.columns:
        ecg_smooth = df['ecg_mv'].rolling(5, min_periods=1).mean()
        fig.add_trace(go.Scatter(x=df['ts'], y=df['ecg_mv'], mode='lines',
                                 line=dict(color=colors['secondary'], width=1, dash='dot'), opacity=0.5),
                      row=2, col=2)
        fig.add_trace(go.Scatter(x=df['ts'], y=ecg_smooth, mode='lines',
                                 line=dict(color=colors['primary'], width=2)), row=2, col=2)

    fig.update_layout(title=dict(text="<b>🏥 Health Monitoring Dashboard</b>", x=0.5),
                      showlegend=False, height=700)
    return {'vital': fig.to_html(full_html=False)}

# ----------------- FLASK ROUTE -----------------
@app.route("/")
def dashboard():
    global latest_data
    status = {}
    if not latest_data.empty:
        latest = latest_data.iloc[-1]
        status = {
            'heart_rate': latest.get('heart_rate', 0),
            'temp_c': latest.get('temp_c', 0),
            'spo2': latest.get('spo2', 0),
            'timestamp': latest.get('ts', datetime.now()),
            'record_count': len(latest_data),
            'device_id': DEVICE_ID
        }

    figures = create_dashboard_figures(latest_data)
    return render_template("dashboard.html", status=status, figures=figures)

# ----------------- MAIN -----------------
if __name__ == "__main__":
    # Start background data update
    threading.Thread(target=update_data, daemon=True).start()
    print("🚀 Starting Flask dashboard on http://127.0.0.1:5000")
    app.run(host='0.0.0.0', port=5050, debug=True)

