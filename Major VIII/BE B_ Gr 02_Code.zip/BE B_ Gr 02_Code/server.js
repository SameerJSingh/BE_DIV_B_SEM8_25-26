const result = require("dotenv").config();
const cors = require("cors");
const axios = require("axios");
const { GoogleGenAI } = require("@google/genai");

if (result.error) {
  console.error("Error loading .env file:", result.error);
} else {
  console.log("Loaded .env file:", result.parsed);
}

const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const authRoutes = require("./routes/auth");
const dashboardRoutes = require("./routes/dashboard");

const app = express();
app.use(cors());

app.use(express.json());

console.log("MONGODB_URI:", process.env.MONGODB_URI);
console.log("JWT_SECRET:", process.env.JWT_SECRET);

const mongoUri =
  process.env.MONGODB_URI ||
  "mongodb+srv://dhiraj:dhiraj@cluster0.fj5f9.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0/Revive";

mongoose
  .connect(mongoUri)
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Could not connect to MongoDB", err));

app.use("/api/auth", authRoutes);
app.use("/api/dashboard", dashboardRoutes);

app.use(express.static(path.join(__dirname, "../")));

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../index.html"));
});

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});


app.use(express.json());
app.use(cors());

const GEMINI_API_KEY = "AIzaSyAsF9201aM6Ln7uZgkNTXy4dKEEo3rjG7A";
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateText?key=${process.env.GEMINI_API_KEY}`;
const ai = new GoogleGenAI({ apiKey: "AIzaSyAsF9201aM6Ln7uZgkNTXy4dKEEo3rjG7A" });

app.post("/chat", async (req, res) => {
  try {
    const userMessage = req.body.message;
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: userMessage,
    });

    const botResponse =
      response.text ||
      "Sorry, I couldn't understand that.";
    res.json({ reply: botResponse });
  } catch (error) {
    console.error("Error communicating with Gemini API:", error?.message);
    res.status(500).json({ reply: "Error fetching response from AI." });
  }
});
